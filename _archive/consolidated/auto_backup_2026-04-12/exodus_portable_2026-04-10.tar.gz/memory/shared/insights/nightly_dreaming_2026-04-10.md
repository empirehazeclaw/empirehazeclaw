# 🌙 Nightly Dreaming Report — 2026-04-10T07:56:43.960377Z

## Analysis Results

### Knowledge Graph
- **entities:** 158
- **relations:** 4628
- **orphans:** 158
- **recommendation:** Connect orphan entities

### Recent Memory
- **files_count:** 63
- **files:** [{'file': 'SOUL.md', 'age_days': 0.8}, {'file': 'wiki-log.md', 'age_days': 0.8}, {'file': 'zettelkasten-workflow.md', 'age_days': 0.8}, {'file': 'wiki-index.md', 'age_days': 0.4}, {'file': 'LEGACY_KNOWLEDGE_BASE.md', 'age_days': 0.8}, {'file': 'wiki-lint-report-2026-04-07.md', 'age_days': 0.8}, {'file': 'MEMORY.md', 'age_days': 0.0}, {'file': 'wiki-growth-workflow.md', 'age_days': 0.8}, {'file': 'reflection_history.md', 'age_days': 0.4}, {'file': '2026-04-05-telegram-patterns.md', 'age_days': 4.7}]

