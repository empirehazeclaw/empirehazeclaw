# CORE_KNOWLEDGE_BASE.md — Wichtigste Erkenntnisse
*Stand: 2026-04-10 | 9 Learnings + 5 Insights*

---

## 🧠 Top Insights aus Learnings & Insights

_Die wichtigsten 50 Erkenntnisse, extrahiert aus dem Memory-System_

### 1. Learning: orchestrator/monitoring/seo_audit_report.js...
**Datum:** 2026-04-09 | **Tags:** [1 (KEINE Meta Description!) | 0 |, store — Meta Description
> ## orchestrator/monitoring/seo_audit_report.js

### 2. Learning: web-orchestrator/monitoring/seo_audit_report.json...
**Datum:** 2026-04-09 | **Tags:** [1 (KEINE Meta Description!) | 0 |, store — Meta Description
> ## web-orchestrator/monitoring/seo_audit_report.json

### 3. Learning: workspace/SECURITY_HARDENING_STATUS.md...
**Datum:** 2026-04-09 | **Tags:** [ÜBERWIEGEND SICHER, Active (Service läuft seit 13:51) |, DE
> ## workspace/SECURITY_HARDENING_STATUS.md

### 4. Learning: /home/clawbot/.openclaw/workspace/memory/EXTRACTIO...
**Datum:** 2026-04-09 | **Tags:** [5,991 messages processed, `memory/decisions/`, `memory/lear
> ## /home/clawbot/.openclaw/workspace/memory/EXTRACTION_BATCH6.md

### 5. Learning: workspace/memory/EXTRACTION_BATCH6.md...
**Datum:** 2026-04-09 | **Tags:** [5,991 messages processed, `memory/decisions/`, `memory/lear
> ## workspace/memory/EXTRACTION_BATCH6.md

### 6. Insight from 2026-03-29.md
**Datum:**  | **Tags:** N/A
> - Neue Leads benötigt: CRM hat viele ungültige Emails

### 7. Insight from 2026-04-05-telegram-learnings.md
**Datum:**  | **Tags:** N/A
> [02.04.2026] [Dev_bot] Fertig. ✅ ─── Workarounds für die 3 Bugs Bug #26802 — Fallback Model wird gecached Symptom: Modell bleibt auf Fallback &quot;stecken&quot; Workaround: # Script ausführen ./scripts/clear_model_overrides.sh openclaw gateway restart Bug #21725 — /new löscht keine Model Overrides Symptom: /new hilft nic

### 8. Insight from 2026-04-05-telegram-patterns.md
**Datum:**  | **Tags:** N/A
> 3. **Telegram Diagnosis** - wurde das Problem gelöst?

### 9. Insight from 2026-04-07-RECOVERED-learnings.md
**Datum:**  | **Tags:** N/A
> 5. Chat History: Extract knowledge not errors


---

## 🌙 Nightly Dreaming Insights
### 1. Insight from .template.md
**Datum:** 
> <!-- Kopiere diese Datei und fülle sie aus -->

### 2. Insight from 2026-04-09_dreaming-aktiviert.md
**Datum:** 
> - Sicherstellen dass Insights auch in Shared KB landen

### 3. Insight from 2026-04-09_shared-insights-system.md
**Datum:** 
> - CEO sollte Compliance monitorn

### 4. Insight from nightly_dreaming_2026-04-09.md
**Datum:** 
> - **files:** [{'file': 'SOUL.md', 'age_days': 0.3}, {'file': 'wiki-log.md', 'age_days': 0.3}, {'file': 'zettelkasten-workflow.md', 'age_days': 0.3}, {'file': 'wiki-index.md', 'age_days': 0.3}, {'file': 'LEGACY_KNOWLEDGE_BASE.md', 'age_days': 0.3}, {'file': 'wiki-lint-report-2026-04-07.md', 'age_days': 0.3}, {'file': 'MEMORY.md', 'age_days': 0.0}, {'file': 'wiki-growth-workflow.md', 'age_days': 0.3}, {'file': 'reflection_history.md', 'age_days': 0.3}, {'file': '2026-04-05-telegram-patterns.md', '

### 5. Insight from nightly_dreaming_2026-04-10.md
**Datum:** 
> - **files:** [{'file': 'SOUL.md', 'age_days': 0.8}, {'file': 'wiki-log.md', 'age_days': 0.8}, {'file': 'zettelkasten-workflow.md', 'age_days': 0.8}, {'file': 'wiki-index.md', 'age_days': 0.4}, {'file': 'LEGACY_KNOWLEDGE_BASE.md', 'age_days': 0.8}, {'file': 'wiki-lint-report-2026-04-07.md', 'age_days': 0.8}, {'file': 'MEMORY.md', 'age_days': 0.0}, {'file': 'wiki-growth-workflow.md', 'age_days': 0.8}, {'file': 'reflection_history.md', 'age_days': 0.4}, {'file': '2026-04-05-telegram-patterns.md', '
